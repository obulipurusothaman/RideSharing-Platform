import { RideBooking } from './ride-booking';

describe('RideBooking', () => {
  it('should create an instance', () => {
    expect(new RideBooking()).toBeTruthy();
  });
});
