import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { from } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { RideBooking } from './ride-booking';
import { RideDistances } from './ride-distances';
import { RideSchedules } from './ride-schedules';
import { RideSchedulesComponent } from './ride-schedules/ride-schedules.component';

@Injectable({
  providedIn: 'root'
})
export class RideScheduleService {

  private baseURL="http://localhost:8080/api/rides/schedule";
  private baseURL1="http://localhost:8080/api/rides/book";
  private baseURL2="http://localhost:8080/api/find";

  private FareURL="http://localhost:8080/api/findAll";
  nativeElement: any;


  constructor(private http:HttpClient) { }


 createRideSchedules(rideSchedules:RideSchedules):Observable<Object>{
  return this.http.post(`${this.baseURL}`,rideSchedules);
 }

 createBooking(rideBooking:RideBooking):Observable<Object>{
  return this.http.post(`${this.baseURL1}`,rideBooking);
 }



    
  //  getDistances(fromLocation:string,toLocation:string,fareAmount:number):Observable<RideDistances[]>{
  //   const url= `${this.baseURL2}?fromLocation=${fromLocation}&toLocation=${toLocation}&fareAmount=${fareAmount}`;
  //   return this.http.get<RideDistances[]>(url);
  //  }

   getMinAndMaxFareAmount(fromLocation:string,toLocation:string,minFare:number,maxFare:number):Observable<RideDistances[]>{
    const url1=`${this.FareURL}?fromLocation=${fromLocation}&toLocation=${toLocation}&minFare=${minFare}&maxFare=${maxFare}`;
    return this.http.get<RideDistances[]>(url1);
   }

   getFareAmount(fromLocation:string,toLocation:string):Observable<any>{
     return this.http.get<any>(`http://localhost:8080/api/${fromLocation}/${toLocation}/rideFare`);
   
   }


}
