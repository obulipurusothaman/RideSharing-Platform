import { RideSchedules } from './ride-schedules';

describe('RideSchedules', () => {
  it('should create an instance', () => {
    expect(new RideSchedules()).toBeTruthy();
  });
});
