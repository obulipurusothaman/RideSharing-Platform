export class RideDistances {
   

    ridefrom:string;
    rideto:string;
    totalfare:number;
    minFare:number;
    maxFare:number;

    


}
