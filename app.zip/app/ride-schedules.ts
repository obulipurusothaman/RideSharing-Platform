import { DatePipe, Time } from "@angular/common";

export class RideSchedules {

    id:number;
    rideFrom:string;
    rideTo:string;
    rideStartsOn:string;
    rideTime:string;
    rideFare:number;
    vehicleRegistrationNo:string;
    motorisUserId:number;
    noOfSeatsAvailable:number;
}
