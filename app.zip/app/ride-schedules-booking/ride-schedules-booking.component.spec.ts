import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RideSchedulesBookingComponent } from './ride-schedules-booking.component';

describe('RideSchedulesBookingComponent', () => {
  let component: RideSchedulesBookingComponent;
  let fixture: ComponentFixture<RideSchedulesBookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RideSchedulesBookingComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RideSchedulesBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
