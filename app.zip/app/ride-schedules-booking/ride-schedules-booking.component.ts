import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { RideBooking } from '../ride-booking';
import { RideScheduleService } from '../ride-schedule.service';
import { RideSchedules } from '../ride-schedules';

@Component({
  selector: 'app-ride-schedules-booking',
  templateUrl:'./ride-schedules-booking.component.html',
  styleUrl: './ride-schedules-booking.component.css'
})
export class RideSchedulesBookingComponent implements OnInit {
  
  rideSchedules:RideSchedules;
  rideSchedulesId:number;

rideBooking:RideBooking=new RideBooking();
bookingId:number;
totalAmount:number;
  constructor(private rideScheduleService:RideScheduleService,private router:Router){
    this.rideBooking=new RideBooking();
    this.rideBooking.rideSchedules=new RideSchedules();
  }
  ngOnInit(): void {
    // const navigation=this.router.getCurrentNavigation();
    // if(navigation&&navigation.extras.state){
    //   this.totalAmount=navigation.extras.state.totalAmount;
    //   this.rideBooking.totalAmount=this.totalAmount;
    // }
    
  }
  ngInit():void{}


  saveRideDistance(){
    if(this.rideBooking.noOfSeats>2){
      alert('Can not Book More Than 2 seats');
      return;
    }
   
    this.rideScheduleService.createBooking(this.rideBooking).subscribe({
      next:(data:any)=>{
      
     this.bookingId=data.bookingId;
     Swal.fire('Success',`Booking Confirmed.Booking ID:${this.bookingId}`);

     console.log(data);
     
    },error:(error:any)=>{
      console.error('Error Occured while Booking:',error);
      alert('An Error Occured while Processing the Booking');
    }
    
  });
  }

  onSubmit(form : NgForm):void{

    this.saveRideDistance();
  
}
}
