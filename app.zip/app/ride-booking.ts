import { RideSchedules } from "./ride-schedules";

export class RideBooking {
    bookedOn:number;
    noOfSeats:number;
    totalAmount:number;
    paymentMode:string;
    riderUserId:number;
    rideSchedules:RideSchedules;//primary key table name
}
