import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RideScheduleService } from '../ride-schedule.service';
import { RideDistances } from '../ride-distances';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-search-rides',
  templateUrl: './search-rides.component.html',
  styleUrl: './search-rides.component.css'
})

export class SearchRidesComponent implements OnInit {
  // filteredRides:RideDistances[]=[];
  filteredRides1:RideDistances[]=[];
  fareRange:number;

  rideDistances:RideDistances=new RideDistances();


  constructor(private rideDistancesService:RideScheduleService,private router:Router){}
  ngOnInit(): void {    
  }


  SaveRideDistances(form){
    
    if(this.rideDistances.ridefrom===this.rideDistances.rideto){
      alert('From and To should not be the same place');
      return;
    }
    
    var fromLocation=this.rideDistances.ridefrom;
    var toLocation=this.rideDistances.rideto;
    var fareAmount=this.rideDistances.totalfare;
    var minFare=this.rideDistances.minFare;
    var maxFare=this.rideDistances.maxFare;
    // this.rideDistancesService.getDistances(fromLocation,toLocation,fareAmount).subscribe(data=>{
    //   this.filteredRides=data;
    //  if(this.filteredRides.length===0){
    //   alert('No ride  avilable for this criteria');
    //  }
    
    // });

    this.rideDistancesService.getMinAndMaxFareAmount(fromLocation,toLocation,minFare,maxFare).subscribe(data=>{
      this.filteredRides1=data;
      if(this.filteredRides1.length===0){
        alert('No Ride Data Available for In This Price Range');

      }
    });
  }
  
  bookRide(ride:RideDistances):void{
    this.router.navigate(['/booking']);
  }
 
  onSubmit(form:NgForm):void {
    

    this.SaveRideDistances(form);

  }

}





