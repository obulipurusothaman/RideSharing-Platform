import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title(title: any) {
    throw new Error('Method not implemented.');
  }
  constructor(private router:Router){
    this.router.events.subscribe(event=>{
      if(event instanceof NavigationEnd){
this.setBackGroudImage(event.url);
      }
    });
  }

  setBackGroudImage(url:string){
    const body=document.getElementsByTagName('body')[0];

    if(url.includes('rideSchedules')){
      body.classList.add('backgroud-image1');
    }
    else if(url.includes('distances')){
      body.classList.add('backgroud-image2')
    }
    else if(url.includes('booking')){
      body.classList.add('backgroud-image3')
    }
    else{
      body.classList.remove('backgroud-image1');
      body.classList.remove('backgroud-image2');
      body.classList.remove('backgroud-image3');
    }
  }
 
 
}
