import { RideDistances } from './ride-distances';

describe('RideDistances', () => {
  it('should create an instance', () => {
    expect(new RideDistances()).toBeTruthy();
  });
});
