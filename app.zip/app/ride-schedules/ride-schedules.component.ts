import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component,OnInit } from '@angular/core';
import {  FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { RideScheduleService } from '../ride-schedule.service';
import { RideSchedules } from '../ride-schedules';


@Component({
  selector: 'app-ride-schedules',
  templateUrl: './ride-schedules.component.html',
  styleUrl: './ride-schedules.component.css'
})

export class RideSchedulesComponent implements OnInit {

  bookingData:any={};

  minDate:string;
  
  rideSchedules:RideSchedules=new RideSchedules();
  fareAmount:number;
  rideSchedulesForm: any;

  constructor(private rideScheduleService:RideScheduleService,private router:Router,private http:HttpClient,private datePipe:DatePipe){}
  
 
    ngOnInit():void{
   this.getCurrentTime();
   this.setMinDate();
   
  }

  setMinDate():void{
    var currentDate=new Date();
    var year=currentDate.getFullYear();
    var month=(currentDate.getMonth()+1).toString().padStart(2,'0');
    var day=(currentDate.getDate()).toString().padStart(2,'0');
    this.minDate=`${year}-${month}-${day}`;

  }

  getCurrentTime():void{
    var currentDate=new Date();
    this.rideSchedules.rideTime=this.datePipe.transform(currentDate,'HH:mm:ss')||'';
  }

  
  // bookRide():void{
  //   this.http.post<any>('http://localhost:8080/api/bookings',this.bookingData).subscribe({
  //     next : (data)=>{
  //     console.log(data);
  //     this.clearForm();
  //   },
  //   error : error=>{
  //     console.error('Error:',error);
  //   }});
  // }
  // clearForm():void{
  //   this.bookingData={};
  // }

    saveRideSchedules():void{
    
      var currentDate=new Date();
      var currentTime=currentDate.getHours()+':'+currentDate.getMinutes()+':'+currentDate.getSeconds();
      if(this.rideSchedules.rideTime<=currentTime){
        alert('Ride Time cannot be past');
        return;
      }
    
      if(this.rideSchedules.vehicleRegistrationNo.length!==10){
    
        alert('Vehicle Registration Number Not More Than 10');
        return;
      }

      if(!this.rideSchedules.vehicleRegistrationNo.match(/[a-zA-Z]{2}[0-9]{2}[a-zA-Z]{2}[0-9]{4}/)){
        alert('Vehicle Registration Number Not is Right Formate');
        return;    

      }
      if(this.rideSchedules.rideFrom===this.rideSchedules.rideTo){
        alert('RideFrom and RideTo should not be the same place');
        return;
      }

      this.rideScheduleService.createRideSchedules(this.rideSchedules).subscribe(data=>{
       
        Swal.fire('Success','RideSchedules Registered Successfully');
      });
       this.router.navigate(['/distances']);
        
    }

    fetchFareAmount():void{
      var fromLocation=this.rideSchedules.rideFrom;
      var toLocation=this.rideSchedules.rideTo;
      if(fromLocation&&toLocation){
        this.rideScheduleService.getFareAmount(fromLocation,toLocation).subscribe(fare=>{
          this.rideSchedules.rideFare=fare;
        });
      }
    }
  
  onSubmit(form : NgForm):void {
    this.saveRideSchedules();
    return;
}
}


