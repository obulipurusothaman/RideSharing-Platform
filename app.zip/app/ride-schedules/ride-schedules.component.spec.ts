import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RideSchedulesComponent } from './ride-schedules.component';

describe('RideSchedulesComponent', () => {
  let component: RideSchedulesComponent;
  let fixture: ComponentFixture<RideSchedulesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RideSchedulesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RideSchedulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
