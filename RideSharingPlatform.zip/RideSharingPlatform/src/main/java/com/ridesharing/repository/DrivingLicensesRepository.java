package com.ridesharing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ridesharing.model.DrivingLicenses;

@Repository
public interface DrivingLicensesRepository extends JpaRepository<DrivingLicenses, Long>{

}
