package com.ridesharing.service;

public interface VehicleTypesServices {

}
