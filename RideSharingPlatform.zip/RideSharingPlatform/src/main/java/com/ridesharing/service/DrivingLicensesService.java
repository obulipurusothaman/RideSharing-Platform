package com.ridesharing.service;

import java.util.Optional;

import com.ridesharing.model.DrivingLicenses;

public interface DrivingLicensesService {
	
	Optional<DrivingLicenses> getDriverLicense(long id);
	DrivingLicenses updateDriverLicense(long id, DrivingLicenses drivingLicense);
	void deleteDriverLicense(long id);
}
