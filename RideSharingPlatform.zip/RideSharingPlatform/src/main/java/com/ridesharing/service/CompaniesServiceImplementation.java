package com.ridesharing.service;

//import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ridesharing.model.Companies;
import com.ridesharing.repository.CompaniesRepository;

@Service
public class CompaniesServiceImplementation implements CompaniesService{
	
	@Autowired
	private CompaniesRepository companiesRepository;
	
	@Override
	public Optional<Companies> getCompany(long id){
		return companiesRepository.findById(id);
	}
	
	@Override
	public Companies updateCompany(long id, Companies company) {
		Optional<Companies> existingCompany = companiesRepository.findById(id);
		if(existingCompany.isPresent()) {
			Companies existingCompanies = existingCompany.get();
            existingCompanies.setCompanyName(company.getCompanyName());
            existingCompanies.setBuildingName(company.getBuildingName());
            return companiesRepository.save(existingCompanies);
		}
		else {
			return null;
		}
	}
	
	@Override
	public void deleteCompany(long id) {
		companiesRepository.deleteById(id);
	}



}
