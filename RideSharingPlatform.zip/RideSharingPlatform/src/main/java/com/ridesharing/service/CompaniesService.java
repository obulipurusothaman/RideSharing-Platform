package com.ridesharing.service;

//import java.util.List;
import java.util.Optional;

//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.RequestBody;

import com.ridesharing.model.Companies;

public interface CompaniesService {
	Optional<Companies> getCompany(long id);
	Companies updateCompany(long id, Companies company);
	void deleteCompany(long id);

}
