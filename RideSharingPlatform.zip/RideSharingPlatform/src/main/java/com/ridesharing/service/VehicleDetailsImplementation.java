package com.ridesharing.service;

public class VehicleDetailsImplementation {

}
