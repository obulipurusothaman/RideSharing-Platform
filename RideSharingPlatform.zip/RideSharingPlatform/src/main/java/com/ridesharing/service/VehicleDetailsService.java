package com.ridesharing.service;

public interface VehicleDetailsService {

}
