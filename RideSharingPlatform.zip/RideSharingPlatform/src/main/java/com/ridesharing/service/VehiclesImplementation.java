package com.ridesharing.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ridesharing.model.Vehicles;
import com.ridesharing.repository.VehiclesRepository;

@Service
public class VehiclesImplementation implements VehiclesService{
    
	private VehiclesRepository vehiclesRepository;
	@Override
	public Vehicles createVehicle(Vehicles vehicles) {
		// TODO Auto-generated method stub
		return vehiclesRepository.save(vehicles);
	}

	@Override
	public List<Vehicles> getAllVehicles() {
		// TODO Auto-generated method stub
		return vehiclesRepository.findAll();
	}
	@Override
	public Optional<Vehicles> getVehicle(String registrationNo) {
		// TODO Auto-generated method stub
		return vehiclesRepository.findById(registrationNo);
	}

	@Override
	public Vehicles updateVehicle(String registrationNo, Vehicles vehicles) {
		// TODO Auto-generated method stub;
		Optional<Vehicles> existingVehiclesOptional=vehiclesRepository.findById(registrationNo);
		
		if(existingVehiclesOptional.isPresent()) {
			Vehicles existingVehicles = existingVehiclesOptional.get();
			existingVehicles.setVehicleTypeId(vehicles.getVehicleTypeId());
			existingVehicles.setInspectionStatus(vehicles.getInspectionStatus());
			existingVehicles.setInspectedByUserId(vehicles.getInspectedByUserId());
			existingVehicles.setInspectedOn(vehicles.getInspectedOn());
			existingVehicles.setInspectionStatus(vehicles.getInspectionStatus());
			
			return vehiclesRepository.save(existingVehicles);
		}
		return null;
	}

	@Override
	public void deleteVehicle(String registrationNo) {
		// TODO Auto-generated method stub
		vehiclesRepository.deleteById(registrationNo);		
	}
	
	

}
