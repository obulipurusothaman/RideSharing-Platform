package com.ridesharing.service;

public class VehicletypesImplementation {

}
