package com.ridesharing.service;

import java.util.Optional;

//import org.springframework.stereotype.Service;

import com.ridesharing.model.UserApplications;

public interface UserApplicationsService {

	Optional<UserApplications> getUserApplication(long userId);
	UserApplications updateUserApplication(long userId, UserApplications userApplications);
	void deleteUserApplication(long userId);
	UserApplications customPostQuery(UserApplications userApplications);
//    Optional<UserApp> getEmployee(int id);//findById()
//    Employee updateEmployee(int id,Employee employee);//saveOrUpdate(101,obley);
//    void deleteEmployee(int id);//deletById() or deleteALL();


}
