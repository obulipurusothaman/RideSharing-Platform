package com.ridesharing.service;

import java.util.List;
import java.util.Optional;
import com.ridesharing.model.Vehicles;

public interface VehiclesService {
	
	Vehicles createVehicle(Vehicles vehicles);
	List<Vehicles> getAllVehicles();
	Optional<Vehicles> getVehicle(String registrationNo);
	Vehicles updateVehicle(String registrationNo, Vehicles vehicles);
	void deleteVehicle(String registrationNo);
	
}
