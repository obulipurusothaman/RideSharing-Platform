package com.ridesharing.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ridesharing.model.UserApplications;
import com.ridesharing.repository.UserApplicationsRepository;

@Service
public class UserApplicationsImplementation implements UserApplicationsService{
	
	@Autowired
	private UserApplicationsRepository userApplicationsRepository;
	
	@Override
	public Optional<UserApplications> getUserApplication(long userId){
		return userApplicationsRepository.findById(userId);
	}
	
	@Override
	public UserApplications updateUserApplication(long userId, UserApplications userApplication) {
		Optional<UserApplications> existingUserApplication = userApplicationsRepository.findById(userId);
		if(existingUserApplication.isPresent()) {
			UserApplications existingUserApplications = existingUserApplication.get();
			existingUserApplications.setUserName(userApplication.getUserName());
            existingUserApplications.setOfficialEmail(userApplication.getOfficialEmail());
            return userApplicationsRepository.save(existingUserApplications);
		}
		else {
			return null;
		}
	}
	
	@Override
	public void deleteUserApplication (long userId) {
		userApplicationsRepository.deleteById(userId);
	}
	
	@Override
	public UserApplications customPostQuery(UserApplications userApplications) {
		String appStatus = userApplications.getApplicationStatus();
		if(appStatus == "New" || appStatus == "Approved" || appStatus == "Rejected") {
			return userApplicationsRepository.save(userApplications);
		} else {
			return null;
		}
	}

}
