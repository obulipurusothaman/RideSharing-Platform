package com.ridesharing.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ridesharing.model.DrivingLicenses;
import com.ridesharing.repository.DrivingLicensesRepository;

@Service
public class DrivingLicensesImplementation implements DrivingLicensesService{
	
	@Autowired
	private DrivingLicensesRepository drivingLicensesRepository;
	
	@Override
	public Optional<DrivingLicenses> getDriverLicense(long id){
		return drivingLicensesRepository.findById(id);
	}
	
	@Override
	public DrivingLicenses updateDriverLicense(long id, DrivingLicenses drivingLicense){
		Optional<DrivingLicenses> existingDriverLicense = drivingLicensesRepository.findById(id);
		if(existingDriverLicense.isPresent()) {
			DrivingLicenses existingDrivingLicenses = existingDriverLicense.get();
			existingDrivingLicenses.setLicensesNo(drivingLicense.getLicensesNo());
			existingDrivingLicenses.setRta(drivingLicense.getRta());
			return drivingLicensesRepository.save(existingDrivingLicenses);
		} else {
			return null;
		}
	}
	
	@Override
	public 	void deleteDriverLicense(long id) {
		drivingLicensesRepository.deleteById(id);
	}
	
}
