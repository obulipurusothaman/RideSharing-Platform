package com.ridesharing.controller;
 
import java.util.Collections;

import java.util.List;

import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
 
import com.ridesharing.model.Vehicles;

import com.ridesharing.service.VehiclesService;
 
@RestController

@RequestMapping("/vehicles")

public class VehiclesController  {

	@Autowired

	private VehiclesService vehiclesservice;

	@PostMapping("/create")

	public ResponseEntity<Vehicles> saveVehicles(@RequestBody Vehicles vehicles){

		Vehicles createdVehicles=vehiclesservice.createVehicle(vehicles);

		return new ResponseEntity<>(createdVehicles,HttpStatus.CREATED);

	}

	@GetMapping("/getAllVehicles")

	public ResponseEntity<List<Vehicles>> getVehicles(){

		List<Vehicles> vehiclesList=vehiclesservice.getAllVehicles();

		if(!vehiclesList.isEmpty()) {

			return new ResponseEntity<>(vehiclesList, HttpStatus.OK);

		}

		else {

			return new ResponseEntity<>(Collections.emptyList(),HttpStatus.OK);

		}

	}

	@GetMapping("/getVehicle/{id}")

	public ResponseEntity<Vehicles>getVehicle(@PathVariable String registrationNo){

		Optional<Vehicles> vehicles=vehiclesservice.getVehicle(registrationNo);

		return vehicles.map(value -> new ResponseEntity<>(value, HttpStatus.OK)).orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));

	}

	@PutMapping("/updateVehicle/{registrationNo}")

	public ResponseEntity<Vehicles> updateVehicle(@PathVariable String registrationNo,@RequestBody Vehicles vehicles)

	{

		Vehicles updatedvehicle=vehiclesservice.updateVehicle(registrationNo,vehicles);

		if(updatedvehicle != null) {

			return new ResponseEntity<>(updatedvehicle, HttpStatus.OK);

		}

		else {

			return new ResponseEntity<>(HttpStatus.NOT_FOUND);

		}

	}

	@DeleteMapping("/deleteVehicle/{registrationNo}")

	public ResponseEntity<Void> deletevehicle(@PathVariable String registrationNo){

		vehiclesservice.deleteVehicle(registrationNo);

		return new ResponseEntity<>(HttpStatus.NO_CONTENT);

	}

 
}

