package com.ridesharing.controller;

public class VehicleTypesController {

}
