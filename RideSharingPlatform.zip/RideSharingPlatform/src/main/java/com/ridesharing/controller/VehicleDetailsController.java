package com.ridesharing.controller;

public class VehicleDetailsController {

}
