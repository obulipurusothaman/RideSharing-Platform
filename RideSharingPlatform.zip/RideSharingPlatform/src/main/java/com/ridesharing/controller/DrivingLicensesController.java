package com.ridesharing.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ridesharing.model.DrivingLicenses;
import com.ridesharing.repository.DrivingLicensesRepository;
import com.ridesharing.service.DrivingLicensesService;

@RestController
@RequestMapping("/licensedata")
public class DrivingLicensesController {
	
	@Autowired
	private DrivingLicensesRepository drivingLicensesRepository;
	@Autowired
	private DrivingLicensesService drivingLicensesService;
	
	@GetMapping("/hello")
	public String hello() {
		return "Hello";
	}
	
	@GetMapping("/drivingLicenses")
	public List<DrivingLicenses> getDrivingLicensesList(){
		return drivingLicensesRepository.findAll();
	}
	
	@GetMapping("/license/{id}")
	public ResponseEntity<DrivingLicenses> getDriverLicense(@PathVariable long id){
		Optional<DrivingLicenses> driverLicense = drivingLicensesService.getDriverLicense(id);
		return driverLicense.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
				.orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}
	
	@PostMapping("/newlicense")
	public DrivingLicenses addNewLicense(@RequestBody DrivingLicenses drivingLicenses) {
		return drivingLicensesRepository.save(drivingLicenses);
	}
	
	@PutMapping("/updatelicense/{id}")
	public ResponseEntity<DrivingLicenses> updateDrivingLicense(@PathVariable long id, @RequestBody DrivingLicenses drivingLicenses){
		DrivingLicenses updatedLicense = drivingLicensesService.updateDriverLicense(id, drivingLicenses);
		if(updatedLicense != null) {
			return new ResponseEntity<> (updatedLicense, HttpStatus.OK);
		}
		else {
			return new ResponseEntity<> (updatedLicense, HttpStatus.NOT_FOUND);
		}
	}
	
	@DeleteMapping("/deletelicense/{id}")
    public ResponseEntity<Void> deleteLicense(@PathVariable long id) {
        drivingLicensesService.deleteDriverLicense(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
