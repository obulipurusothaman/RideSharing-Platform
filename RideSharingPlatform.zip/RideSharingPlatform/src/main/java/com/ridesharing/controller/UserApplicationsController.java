package com.ridesharing.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ridesharing.model.UserApplications;
import com.ridesharing.repository.UserApplicationsRepository;
import com.ridesharing.service.UserApplicationsService;
//import com.ridesharing.repository.UserApplicationsRepository;

@RestController
@RequestMapping("/userapplication")
public class UserApplicationsController {
	
	@Autowired
	private UserApplicationsRepository userApplicationsRepository;
	@Autowired
	private UserApplicationsService userApplicationsService;
	
	@GetMapping("/hello")
	public String hello() {
		return "Hello";
	}
	
	@GetMapping("/application")
	public List<UserApplications> getUserApplicationsList(){
		return userApplicationsRepository.findAll();
	}
	
	@GetMapping("/apllicationid/{userId}")
	public ResponseEntity<UserApplications> getUserApplication(@PathVariable long userId){
		Optional<UserApplications> userApplication = userApplicationsService.getUserApplication(userId);
		return userApplication.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
				.orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
		
	}
	
	@DeleteMapping("/deleteuserapplication/{userId}")
    public ResponseEntity<Void> deleteUserApplication(@PathVariable long userId) {
        userApplicationsService.deleteUserApplication(userId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
	
	@PutMapping("/updateapplication/{userId}")
	public ResponseEntity<UserApplications> updateUserApplication(@PathVariable long userId, @RequestBody UserApplications userApplication){
		UserApplications updatedUserApplication = userApplicationsService.updateUserApplication(userId, userApplication);
		if(updatedUserApplication != null) {
			return new ResponseEntity<> (updatedUserApplication, HttpStatus.OK);
		}
		else {
			return new ResponseEntity<> (updatedUserApplication, HttpStatus.NOT_FOUND);
		}
	}
	
	
	@PostMapping("/custompost")
		public UserApplications customPostQuery(@RequestBody UserApplications userApplications) {
			return userApplicationsService.customPostQuery(userApplications);
		}
	
	@PostMapping("/newapplication")
	public UserApplications addNewApllication(@RequestBody UserApplications userApplications) {
		return userApplicationsRepository.save(userApplications);
	}

}
