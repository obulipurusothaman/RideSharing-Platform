
package com.ridesharing.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;



@Entity
@Table(name="VehicleDetails")
public class VehicleDetails {
	@Id
	@Column(name="RTOName")
	private String rtoName;
	@Column(name="RegistrationDate")
	private Date registrationDate;
	@Column(name="RegistrationExpiresOn")
	private Date registrationExpiresOn;
	@Column(name="RCdocURL")
	private String rcDocURL;
	@Column(name="InsuranceCompanyName")
	private String insuranceCompanyName;
	@Column(name="InsuranceNo")
	private int insuranceNo;
	@Column(name="InsuredOn")
	private Date insuredOn;
	@Column(name="InsuranceExpiresOn")
	private Date insuranceExpiresOn;
	@Column(name="InsuranceCertificateDOCURL")
	private String insuranceCertificateDocURL;
	@Column(name="PUCCertificateNo")
	private int pucCertificateNo;
	@Column(name="PUCIssuedOn")
	private Date pucIssuedOn;
	@Column(name="PUCValidUntil")
	private Date pucValidUntil;
	@Column(name="PUCDOCURL")
	private String pucDocURL;
	@Column(name="RegistrationNo")
	private String registrationNo;
	public String getRegistrationNo() {
		return registrationNo;
	}
	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}
	public String getRtoName() {
		return rtoName;
	}
	public void setRtoName(String rtoName) {
		this.rtoName = rtoName;
	}
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	public Date getRegistrationExpiresOn() {
		return registrationExpiresOn;
	}
	public void setRegistrationExpiresOn(Date registrationExpiresOn) {
		this.registrationExpiresOn = registrationExpiresOn;
	}
	public String getRcDocURL() {
		return rcDocURL;
	}
	public void setRcDocURL(String rcDocURL) {
		this.rcDocURL = rcDocURL;
	}
	public String getInsuranceCompanyName() {
		return insuranceCompanyName;
	}
	public void setInsuranceCompanyName(String insuranceCompanyName) {
		this.insuranceCompanyName = insuranceCompanyName;
	}
	public int getInsuranceNo() {
		return insuranceNo;
	}
	public void setInsuranceNo(int insuranceNo) {
		this.insuranceNo = insuranceNo;
	}
	public Date getInsuredOn() {
		return insuredOn;
	}
	public void setInsuredOn(Date insuredOn) {
		this.insuredOn = insuredOn;
	}
	public Date getInsuranceExpiresOn() {
		return insuranceExpiresOn;
	}
	public void setInsuranceExpiresOn(Date insuranceExpiresOn) {
		this.insuranceExpiresOn = insuranceExpiresOn;
	}
	public String getInsuranceCertificateDocURL() {
		return insuranceCertificateDocURL;
	}
	public void setInsuranceCertificateDocURL(String insuranceCertificateDocURL) {
		this.insuranceCertificateDocURL = insuranceCertificateDocURL;
	}
	public int getPucCertificateNo() {
		return pucCertificateNo;
	}
	public void setPucCertificateNo(int pucCertificateNo) {
		this.pucCertificateNo = pucCertificateNo;
	}
	public Date getPucIssuedOn() {
		return pucIssuedOn;
	}
	public void setPucIssuedOn(Date pucIssuedOn) {
		this.pucIssuedOn = pucIssuedOn;
	}
	public Date getPucValidUntil() {
		return pucValidUntil;
	}
	public void setPucValidUntil(Date pucValidUntil) {
		this.pucValidUntil = pucValidUntil;
	}
	public String getPucDocURL() {
		return pucDocURL;
	}
	public void setPucDocURL(String pucDocURL) {
		this.pucDocURL = pucDocURL;
	}
	
	
	@ManyToOne
	@JoinColumn(name="RegistrationNo")
	private Vehicles RegistrationNo;
	public void setRegistrationNo(Vehicles registrationNo) {
		RegistrationNo = registrationNo;
	}
}
