package com.ridesharing.model;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;


@Entity
@Table(name = "DrivingLicenses")

public class DrivingLicenses {
 
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @OneToOne
    @JoinColumn(name="userId", referencedColumnName = "userId")
    private UserApplications userId;
    private String licensesNo;
    private String rta;
    private String allowedVehicles;
    private Date expirationDate;
    public Date getExpirationDate() {
    	return expirationDate;
    }
    public void setExpirationDate(Date expirationDate) {
    	this.expirationDate = expirationDate;
    }
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public UserApplications getUserId() {
		return userId;
	}
	public void setUserId(UserApplications userId) {
		this.userId = userId;
	}
	public String getLicensesNo() {
		return licensesNo;
	}
	public void setLicensesNo(String licensesNo) {
		this.licensesNo = licensesNo;
	}
	public String getRta() {
		return rta;
	}
	public void setRta(String rta) {
		this.rta = rta;
	}
	public String getAllowedVehicles() {
		return allowedVehicles;
	}
	public void setAllowedVehicles(String allowedVehicles) {
		this.allowedVehicles = allowedVehicles;
	}
	public DrivingLicenses() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
