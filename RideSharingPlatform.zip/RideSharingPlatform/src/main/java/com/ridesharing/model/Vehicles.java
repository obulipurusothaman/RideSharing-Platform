package com.ridesharing.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Vehicles")
public class Vehicles {
	@Id
	private String registrationNo;

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public int getBelongsToUserId() {
		return belongsToUserId;
	}

	public void setBelongsToUserId(int belongsToUserId) {
		this.belongsToUserId = belongsToUserId;
	}

	public int getVehicleTypeId() {
		return vehicleTypeId;
	}

	public void setVehicleTypeId(int vehicleTypeId) {
		this.vehicleTypeId = vehicleTypeId;
	}

	public String getInspectionStatus() {
		return inspectionStatus;
	}

	public void setInspectionStatus(String inspectionStatus) {
		this.inspectionStatus = inspectionStatus;
	}

	public int getInspectedByUserId() {
		return inspectedByUserId;
	}

	public void setInspectedByUserId(int inspectedByUserId) {
		this.inspectedByUserId = inspectedByUserId;
	}

	public Date getInspectedOn() {
		return inspectedOn;
	}

	public void setInspectedOn(Date inspectedOn) {
		this.inspectedOn = inspectedOn;
	}

	

	@Column(name = "BelongsToUserId")
	private int belongsToUserId;
	@Column(name = "VehicleTypeId")
	private int vehicleTypeId;
	@Column(name = "InspectionStatus")
	private String inspectionStatus;
	@Column(name = "InspectedByUserId")
	private int inspectedByUserId;
	@Column(name = "InspectedOn")
	private Date inspectedOn;
	@ManyToOne
	@JoinColumn(name = "VehicleTypeId")
	private VehicleTypes ID;
	
	

	public VehicleTypes getID() {
		return ID;
	}

	public void setID(VehicleTypes iD) {
		ID = iD;
	}
}
