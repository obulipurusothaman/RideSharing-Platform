package com.ridesharing.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Companies")
public class Companies {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String companyName;
	private String buildingName;
	private String securityInchargeName;
	private String securityHelpDeskNumber;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public String getSecurityInchargeName() {
		return securityInchargeName;
	}
	public void setSecurityInchargeName(String securityInchargeName) {
		this.securityInchargeName = securityInchargeName;
	}
	public String getSecurityHelpDeskNumber() {
		return securityHelpDeskNumber;
	}
	public void setSecurityHelpDeskNumber(String securityHelpDeskNumber) {
		this.securityHelpDeskNumber = securityHelpDeskNumber;
	}
	public Companies() {
		super();
	}
	
	

}
