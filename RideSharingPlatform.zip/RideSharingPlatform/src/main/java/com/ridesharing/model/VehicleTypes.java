package com.ridesharing.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Vehicle_Types")
public class VehicleTypes {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getMaxPessangersAllowed() {
		return maxPessangersAllowed;
	}
	public void setMaxPessangersAllowed(int maxPessangersAllowed) {
		this.maxPessangersAllowed = maxPessangersAllowed;
	}
	public int getFarePerKM() {
		return farePerKM;
	}
	public void setFarePerKM(int farePerKM) {
		this.farePerKM = farePerKM;
	}
	@Column(name="Vehicle_Type")
	private int type;
	@Column(name="MaxPassengersAllowed")
	private int maxPessangersAllowed;
	@Column(name="FarePerKM")
	private int farePerKM;

}
