package com.RideSharingManagementModule.RideSharingModule;

import org.assertj.core.api.Assertions;
import org.joda.time.DateTime;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.when;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertEquals;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.RequestBody;

import com.RideSharingManagementModule.RideSharingModule.Model.Booking;
import com.RideSharingManagementModule.RideSharingModule.Model.Distances;
import com.RideSharingManagementModule.RideSharingModule.Model.RideSchedules;
import com.RideSharingManagementModule.RideSharingModule.Repository.BookingRepository;
import com.RideSharingManagementModule.RideSharingModule.Repository.DistancesRepository;
import com.RideSharingManagementModule.RideSharingModule.Repository.RideSchedulesRepository;
import com.RideSharingManagementModule.RideSharingModule.Service.BookingService;
import com.RideSharingManagementModule.RideSharingModule.Service.DistancesService;
import com.RideSharingManagementModule.RideSharingModule.Service.RideSchedulesService;


import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@SpringBootTest
@RunWith(SpringRunner.class)
class RideSharingModuleApplicationTests {

	//Booking
	@Autowired
	private BookingService bookingservice;
	
	@MockBean 
	private BookingRepository bookingrepository;
	
	@Test
	public void getAllBookingTest() {
	when(bookingrepository.findAll()).thenReturn(Stream.of(new Booking()).collect(Collectors.toList()));
	
	assertEquals(1,bookingservice.getAllBooking().size());
	
	}
	
	
	
	
	
	//Distance
	@Autowired
	private DistancesService distancesservice;
	
	@MockBean
	private DistancesRepository distancesrepository;
	
	@Test
	public void getAllDistances() {
		when(distancesrepository.findAll()).thenReturn(Stream.of(new Distances()).collect(Collectors.toList()));
		assertEquals(1,distancesservice.getAllDistances().size()); //validating purpose whether two asserts are equals or not
		
	}
	
	
	
	
	
	//RideSchedule
	
	@Autowired
	private RideSchedulesService ridescheduleservice;
	
	@MockBean
	private RideSchedulesRepository rideschedulesrepository;
	
	@Test
	public void getAllRideSchedules() {
		when(rideschedulesrepository.findAll()).thenReturn(Stream.of(new RideSchedules(1, "Chennai","Namakkal", new Date(), null, 400, "TN28AZ4587", 5, 10)).collect(Collectors.toList()));
		assertEquals(1,ridescheduleservice.getAllRideSchedules().size());
	}
	
	
	@Test
	public void saveRideSchedulesTest() {
		RideSchedules rideschedule= new RideSchedules(1,"Salem","Namakkal",new Date(), null, 200, "TN28AZ5465", 12, 2);

		when(rideschedulesrepository.save(rideschedule)).thenReturn(rideschedule);
		RideSchedules rideschedule1 = ridescheduleservice.createRideSchedules(rideschedule);
		assertEquals(rideschedule,rideschedule1);
	}
	
//	@Test
//    public void testGetRideByFareValue() {
//        // Arrange
//        String rideFrom = "Chennai";
//        String rideTo = "Hyderabad";
//        double expectedRideFare = 2000; // Set your expected fare value here
//
//        RideSchedules rideSchedulesService;
//		// Act
//        ResponseEntity<Long> response = rideSchedulesService.getRideByFareValue(rideFrom, rideTo);
//
//        // Assert
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(expectedRideFare, response.getBody());
//    }
		
		
		
	@Test
	public void saveBookingTest() {
		Booking booking= new Booking(1,2,4,20000,"Phone Pay",4,null);

		
		when(bookingrepository.save(booking)).thenReturn(booking);
		Booking booking1 = bookingservice.createBooking(booking);
		assertEquals(booking,booking1);
	}
		
//	@Test
//	public void testGetParticularRequest() {
//		RideSchedules extensionRequests = new RideSchedules(1,"Karur","Namakkal",new Date(), null, 100, "TN29AZ5365", 10, 3);
//		Optional<RideSchedules> optional = Optional.of(extensionRequests);
//		when(rideschedulesrepository.findById(1)).thenReturn(optional);
//		Optional<RideSchedules> req = ridescheduleservice.getRideSchedules(1);
//		assertEquals(extensionRequests,req.get());
//	}
	
	@Test
	public void testFareAmountWithDistance() {
		Distances distances = new Distances(1,"chennai","coimbatore",75,4,1800);
        distances.setDistancekms(5);
        distances.setFareperkms(5);
        double fareAmount =distancesservice.calculateFare(distances);
        distances.setTotalfare(fareAmount);
        
        assertEquals(25.0,fareAmount,1);
	
	}
	
	
	
	

		
		
	}
