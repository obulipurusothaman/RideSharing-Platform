package com.RideSharingManagementModule.RideSharingModule.Controller;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.RideSharingManagementModule.RideSharingModule.Model.Booking;
import com.RideSharingManagementModule.RideSharingModule.Model.RideSchedules;
import com.RideSharingManagementModule.RideSharingModule.Service.BookingService;

import com.RideSharingModule.ExceptionHandling.NoOfSeatsExistsException;
@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api") 
public class BookingController {

	Logger logger = LoggerFactory.getLogger(BookingController.class);

	@Autowired
	private BookingService bookingService;


	@PostMapping("/rides/book")
	public ResponseEntity<Booking>  saveBooking(@RequestBody Booking booking) {
		
		if (booking.getNoOfSeats() == 1 || booking.getNoOfSeats() == 2) {
			
	Booking createdBooking = bookingService.createBooking(booking);
			return new ResponseEntity<>(createdBooking, HttpStatus.CREATED);
			

		}
	
		throw new NoOfSeatsExistsException("Can't Book More Than Two Seats");
		

	}

	@GetMapping("/getAllBooking")
	public ResponseEntity<List<Booking>> getAllRideSchedules() {
	
		logger.info("All the Booking values are getting");

		List<Booking> bookingList = bookingService.getAllBooking();
		if (!bookingList.isEmpty()) {
			return new ResponseEntity<>(bookingList, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
		}

	}

	@GetMapping("/getBooking/{bookingId}")
	public ResponseEntity<Booking> getBookingById(@PathVariable int bookingId) {

		//logger.info("get by the Id");
		Optional<Booking> booking = bookingService.getBooking(bookingId);
		return booking.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
				.orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));

	}

	@GetMapping("/getBookingSeats/{noOfSeats}")
	public ResponseEntity<Booking> getBookingByNoOfSeats(@PathVariable int noOfSeats1) {
		Optional<Booking> bookingSeats = bookingService.getNoOfSeats(noOfSeats1);
		return bookingSeats.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
				.orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
	

	}

	@PutMapping("/updateBooking/{bookingId}")
	public ResponseEntity<Booking> updateBooking(@PathVariable int bookingId, @RequestBody Booking booking) {
		Booking updatedBooking = bookingService.updateBooking(bookingId, booking);
		if (updatedBooking != null) {
			return new ResponseEntity<>(updatedBooking, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

	@DeleteMapping("/deleteBooking/{bookingId}")
	public ResponseEntity<Void> deleteByBookingId(@PathVariable int bookingId) {
		bookingService.deleteByBookingId(bookingId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	// these two are custom queries

	@GetMapping("/bookingFetch")
	public List<Booking> fetchController() {
		return bookingService.fetchAll();
	}

	@GetMapping("/bookingMode/{paymentMode}")
	public Booking fetchMode(@PathVariable String paymentMode) {
		return bookingService.fetchUsingBookingMode(paymentMode);
	}
	
	
//	@GetMapping("/booking/{bookingId}/rideSchedules")
//	public ResponseEntity<RideSchedules> getRideSchedulesByBookingId(@PathVariable int bookingId){
//		RideSchedules rideSchedules=bookingService.findRideSchedulesByBookingId(bookingId);
//		if(rideSchedules!=null) {
//			return ResponseEntity.ok(rideSchedules);
//		}
//		else {
//			return ResponseEntity.notFound().build();
//		}
//	}
	
	



}
