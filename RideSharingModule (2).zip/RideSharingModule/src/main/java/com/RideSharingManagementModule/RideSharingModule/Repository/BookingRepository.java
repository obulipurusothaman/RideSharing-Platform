package com.RideSharingManagementModule.RideSharingModule.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.RideSharingManagementModule.RideSharingModule.Model.Booking;

@Repository
public interface BookingRepository extends JpaRepository<Booking,Integer> 

{

	@Query(value="select b from Booking b") //alias name need to use here we can't use astrick(*) here
	
	public List<Booking> fetchAllFromBooking();
	
	@Query(value="select b from Booking b where paymentMode=:val")
	public Booking fetchUsingBookingMode(@Param("val") String payment_mode);//@Param used as a parameter in that specifiy variable=val and next is passing value is int

	@Query(value="select b from Booking b where b.noOfSeats=:val")
	public Optional<Booking> findByNoOfSeats(@Param("val") int no_of_seats);
	
	
	
//	@Query(value="INSERT INTO Booking(noOfSeats,paymentMode) VALUES ()")

}
