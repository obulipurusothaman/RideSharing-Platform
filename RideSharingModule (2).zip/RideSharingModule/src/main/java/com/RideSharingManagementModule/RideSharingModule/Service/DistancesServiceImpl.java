package com.RideSharingManagementModule.RideSharingModule.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.RideSharingManagementModule.RideSharingModule.Model.Distances;
import com.RideSharingManagementModule.RideSharingModule.Repository.DistancesRepository;


@Service
public class DistancesServiceImpl implements DistancesService {
	@Autowired
	private DistancesRepository distancesRepository;
	
	

	@Override
	public List<Distances> getAllDistances() {
		List<Distances> distance=distancesRepository.findAll();
		return distance;
		
	}

	@Override
	public Optional<Distances> getDistances(int id) {
		
		return distancesRepository.findById(id);
	}

	@Override
	public Distances updateDistances(int id, Distances distances) {
		 Optional<Distances> existingDistancesOptional =distancesRepository.findById(id);
		 if (existingDistancesOptional.isPresent()) {
			 Distances existingDistances = existingDistancesOptional.get();
//	            existingEmployee.setName(employee.getName());
//	            existingEmployee.setSalary(employee.getSalary());
	            // Update other fields as needed
			 existingDistances.setDistancekms(distances.getDistancekms());
			 existingDistances.setId(distances.getId());

	            return distancesRepository.save(existingDistances);
	        } else {
	            // Handle the case where the employee with the given id is not found
	            return null; // You can throw an exception or return a meaningful response
	        }
	}

	@Override
	public void deleteByDistanceId(int id) {
		distancesRepository.deleteById(id);
		
		
	}


	public List<Distances> fetchAll() {
		
		return distancesRepository.fetchAllFromDistances();
	}

	
	public Distances fetchUsingRideFrom(String ridefrom) {
		
		return distancesRepository.fetchUsingRideFrom(ridefrom);
	}

	@Override
	public List<Distances> fetchAllDistances() {
		// TODO Auto-generated method stub
		return distancesRepository.fetchAllDistances();
	}

	@Override
	public Distances createDistances(Distances distances) {
		double amount=distances.getDistancekms()*distances.getFareperkms();
		distances.setTotalfare(amount);
		return distancesRepository.save(distances);
	}

	
	public double calculateFare(Distances distances) {
		
		return distances.getDistancekms()*distances.getFareperkms();
	}

	@Override
	public Distances fetchRideFare(int id) {
		
		return distancesRepository.fetchAllRideFare(id);
	}

	@Override
	public List<Distances> findAvailableRides(String fromLocation, String toLocation,double fareAmount) {
		
		return distancesRepository.findAvailableRides(fromLocation, toLocation,fareAmount);
	}

	
	 @Override
	    public List<Distances> findAvailableRidesByFareRange(String fromLocation, String toLocation, Double minFare, Double maxFare) {
	        // Implement logic to filter rides based on fare range
	        return distancesRepository.findAvailableRidesByFareRange(fromLocation, toLocation, minFare, maxFare);
	    }
	}

	

//	@Override
//	public List<Distances> findDistanceDetails(String ridefrom, String rideto, double totalfare) {
//		// TODO Auto-generated method stub
//		return distancesRepository.findDistanceDetails(ridefrom, rideto, totalfare);
//	}

	
	

	
	
	

	
	

