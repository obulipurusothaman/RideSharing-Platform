package com.RideSharingManagementModule.RideSharingModule.Controller;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.geo.Distance;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.RideSharingManagementModule.RideSharingModule.Model.Distances;
import com.RideSharingManagementModule.RideSharingModule.Repository.DistancesRepository;
import com.RideSharingManagementModule.RideSharingModule.Service.DistancesService;
import com.RideSharingManagementModule.RideSharingModule.Service.DistancesServiceImpl;
@CrossOrigin(origins="http://localhost:4200")
@RestController 
@RequestMapping("/api")
public class DistancesController {

	@Autowired
	private DistancesService distancesService;
//	@Autowired
//	private DistancesServiceImpl distancesServiceImpl;
	@Autowired
	private DistancesRepository distacesRepository;

	@PostMapping("/create")
	public ResponseEntity<Distances> saveDistances(@RequestBody Distances distances) {
		Distances createdDistances = distancesService.createDistances(distances);
		return new ResponseEntity<>(createdDistances, HttpStatus.CREATED);
	}

	@GetMapping("/distances")
	public ResponseEntity<List<Distances>> getAllDistances() {
		List<Distances> distanceList = distancesService.getAllDistances();
		if (!distanceList.isEmpty()) {
			return new ResponseEntity<>(distanceList, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
		}

	}

	@GetMapping("/getDistances/{id}")
	public ResponseEntity<Distances> getDistancesById(@PathVariable int id) {
		Optional<Distances> distance = distancesService.getDistances(id);
		return distance.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
				.orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));

	}

	@PutMapping("/updateDistances/{id}")
	public ResponseEntity<Distances> updateDistances(@PathVariable int id, @RequestBody Distances distances) {
		Distances updatedDistances = distancesService.updateDistances(id, distances);
		if (updatedDistances != null) {
			return new ResponseEntity<>(updatedDistances, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

	@DeleteMapping("/deleteDistances/{id}")
	public ResponseEntity<Void> deleteByDistanceId(@PathVariable int id) {
		distancesService.deleteByDistanceId(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	// custom query

	@GetMapping("/distancesFetch")
	public List<Distances> fetchController() {
		return distancesService.fetchAll();
	}

	@GetMapping("/distancesFrom/{ridefrom}")
	public Distances fetchRideFrom(@PathVariable String ridefrom) { 
		return distancesService.fetchUsingRideFrom(ridefrom);
	}

	@GetMapping("/fetchAllDistances")
	public List<Distances> fetchDistances() {
		return distancesService.fetchAllDistances();
	}

	@GetMapping("/rides/calculateFare/{id}")
	public double calculateFare(@PathVariable int id ) {
		Optional<Distances> distances = distacesRepository.findById(id);
		return distances.get().getTotalfare();

	}
	
	@GetMapping("/find")
	public List<Distances> findAvailableRides(@RequestParam (required = false) String fromLocation,@RequestParam (required = false) String toLocation,@RequestParam(required=false)double fareAmount){
		return distancesService.findAvailableRides(fromLocation, toLocation,fareAmount);
	}
	
	
	//its an optional it wont throw exception while value its not found means
	



@GetMapping("/findAll")
public List<Distances> findAvailableRides(
    @RequestParam(required = false) String fromLocation,
    @RequestParam(required = false) String toLocation,
    @RequestParam(required = false) Double minFare,
    @RequestParam(required = false) Double maxFare) {
    
    if (minFare != null && maxFare != null) {
        // Filter rides based on fare range
        return distancesService.findAvailableRidesByFareRange(fromLocation, toLocation, minFare, maxFare);
    } else {
        // Return all rides if fare range is not specified
        return distancesService.findAvailableRides(fromLocation, toLocation, 0);
    }
}
	
	
	
	
	
	
}
