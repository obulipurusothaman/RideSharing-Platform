package com.RideSharingManagementModule.RideSharingModule.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Distances {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String ridefrom;
	private String rideto;
	//@Column(name="distance_in_kms")
	private int distancekms;
	private int fareperkms;
	private double totalfare=distancekms*fareperkms;

	public Distances() {
		
	}
	
	
	public Distances(int id, String ridefrom, String rideto, int distancekms,int fareperkms,double totalfare) {
		super();
		this.id = id;
		this.ridefrom = ridefrom;
		this.rideto = rideto;
		this.distancekms = distancekms;
		this.fareperkms=fareperkms;
		this.totalfare=totalfare;
	}







	

	public int getFareperkms() {
		return fareperkms;
	}



	public void setFareperkms(int fareperkms) {
		this.fareperkms = fareperkms;
	}



	public double getTotalfare() {
		return totalfare;
	}



	public void setTotalfare(double totalfare) {
		this.totalfare = totalfare;
	}



	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRidefrom() {
		return ridefrom;
	}
	public void setRidefrom(String ridefrom) {
		this.ridefrom = ridefrom;
	}
	public String getRideto() {
		return rideto;
	}
	public void setRideto(String rideto) {
		this.rideto = rideto;
	}
	public int getDistancekms() {
		return distancekms;
	}
	public void setDistancekms(int distancekms) {
		this.distancekms = distancekms;
	}



	@Override
	public String toString() {
		return "Distances [id=" + id + ", ridefrom=" + ridefrom + ", rideto=" + rideto + ", distancekms=" + distancekms
				+ ", fareperkms=" + fareperkms + ", totalfare=" + totalfare + "]";
	}
	
	
}
