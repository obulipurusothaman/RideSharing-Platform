package com.RideSharingManagementModule.RideSharingModule.Service;

import java.util.List;
import java.util.Optional;

import com.RideSharingManagementModule.RideSharingModule.Model.Distances;

public interface DistancesService {
	Distances createDistances(Distances distances);

	List<Distances> getAllDistances();

	Optional<Distances> getDistances(int id);

	Distances updateDistances(int id, Distances distances);

	void deleteByDistanceId(int id);

	List<Distances> fetchAll();

	Distances fetchUsingRideFrom(String ridefrom);

	List<Distances> fetchAllDistances();
	
	double calculateFare(Distances distances);
	
	Distances fetchRideFare(int id);
	List<Distances> findAvailableRides(String fromLocation,String toLocation,double fareAmount);
	
	 List<Distances> findAvailableRidesByFareRange(String fromLocation, String toLocation, Double minFare, Double maxFare);
	

	
	


}
