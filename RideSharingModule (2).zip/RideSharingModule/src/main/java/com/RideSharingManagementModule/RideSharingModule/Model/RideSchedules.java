package com.RideSharingManagementModule.RideSharingModule.Model;


import java.sql.Time;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;



@Entity

public class RideSchedules {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String rideFrom;
	private String rideTo;
	private Date rideStartsOn;
	private Time rideTime;
	private int rideFare;
	private String vehicleRegistrationNo;
	private int motorisUserId;
	private int noOfSeatsAvailable;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRideFrom() {
		return rideFrom;
	}
	public void setRideFrom(String rideFrom) {
		this.rideFrom = rideFrom;
	}
	public String getRideTo() {
		return rideTo;
	}
	public void setRideTo(String rideTo) {
		this.rideTo = rideTo;
	}
	public Date getRideStartsOn() {
		return rideStartsOn;
	}
	public void setRideStartsOn(Date rideStartsOn) {
		this.rideStartsOn = rideStartsOn;
	}
	public Time getRideTime() {
		return rideTime;
	}
	public void setRideTime(Time rideTime) {
		this.rideTime = rideTime;
	}
	public int getRideFare() {
		return rideFare;
	}
	public void setRideFare(int rideFare) {
		this.rideFare = rideFare;
	}
	public String getVehicleRegistrationNo() {
		return vehicleRegistrationNo;
	}
	public void setVehicleRegistrationNo(String vehicleRegistrationNo) {
		this.vehicleRegistrationNo = vehicleRegistrationNo;
	}
	public int getMotorisUserId() {
		return motorisUserId;
	}
	public void setMotorisUserId(int motorisUserId) {
		this.motorisUserId = motorisUserId;
	}
	public int getNoOfSeatsAvailable() {
		return noOfSeatsAvailable;
	}
	public void setNoOfSeatsAvailable(int noOfSeatsAvailable) {
		this.noOfSeatsAvailable = noOfSeatsAvailable;
	}
	public RideSchedules(int id, String rideFrom, String rideTo, Date rideStartsOn, Time rideTime, int rideFare,
			String vehicleRegistrationNo, int motorisUserId, int noOfSeatsAvailable) {
		super();
		this.id = id;
		this.rideFrom = rideFrom;
		this.rideTo = rideTo;
		this.rideStartsOn = rideStartsOn;
		this.rideTime = rideTime;
		this.rideFare = rideFare;
		this.vehicleRegistrationNo = vehicleRegistrationNo;
		this.motorisUserId = motorisUserId;
		this.noOfSeatsAvailable = noOfSeatsAvailable;
	}
	
	public  RideSchedules() {
		
	}
	@Override
	public String toString() {
		return "RideSchedules [id=" + id + ", rideFrom=" + rideFrom + ", rideTo=" + rideTo + ", rideStartsOn="
				+ rideStartsOn + ", rideTime=" + rideTime + ", rideFare=" + rideFare + ", vehicleRegistrationNo="
				+ vehicleRegistrationNo + ", motorisUserId=" + motorisUserId + ", noOfSeatsAvailable="
				+ noOfSeatsAvailable + "]";
	}
	
	
	
	
}
