package com.RideSharingManagementModule.RideSharingModule.Service;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import com.RideSharingManagementModule.RideSharingModule.Model.Booking;
import com.RideSharingManagementModule.RideSharingModule.Model.Distances;
import com.RideSharingManagementModule.RideSharingModule.Model.RideSchedules;
import com.RideSharingManagementModule.RideSharingModule.Repository.DistancesRepository;
import com.RideSharingManagementModule.RideSharingModule.Repository.RideSchedulesRepository;
import com.RideSharingManagementModule.RideSharingModule.dto.VehiclesDTO;
import com.RideSharingModule.ExceptionHandling.BookingCreationFailed;



@Service
public class RideSchedulesServiceImpl implements RideSchedulesService {

	@Autowired
	private RideSchedulesRepository rideschedulesRepository;
	
	@Autowired
	private DistancesRepository distancesRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	public RideSchedulesServiceImpl(RideSchedulesRepository rideschedulesRepository,DistancesRepository distancesRepository) {
		this.rideschedulesRepository=rideschedulesRepository;
		this.distancesRepository=distancesRepository;
	}
	
	@Override
	public RideSchedules createRideSchedules(RideSchedules rideschedules) {
		

		return rideschedulesRepository.save(rideschedules);
		
	}

	@Override
	public List<RideSchedules> getAllRideSchedules() {
		
		return rideschedulesRepository.findAll();
	}

	@Override
	public Optional<RideSchedules> getRideSchedules(int id) {
		Optional<RideSchedules>ride=rideschedulesRepository.findById(id);
		VehiclesDTO v=restTemplate.getForObject("http://localhost:8081/vehicles/getVehicleById/"+ride.get().getVehicleRegistrationNo(),VehiclesDTO.class);
		System.out.println(v.getInspectionStatus());
		System.out.println(v.getRegistrationNo());
		System.out.println(ride.get().getVehicleRegistrationNo());
//		if(v.getInspectionStatus().equalsIgnoreCase("Approved")) {
//		return bs.createBooking(b);
//	    }
//	   else {
//		throw new BookingCreationFailed("Can't Book an Ride Because Vehicle Not Approved");
//	     }
		
		return ride;
	}

	@Override
	public RideSchedules updateRideSchedules(int id, RideSchedules rideschedules) {
		 Optional<RideSchedules> existingRideSchedulesOptional =rideschedulesRepository.findById(id);
		 if (existingRideSchedulesOptional.isPresent()) {
			 RideSchedules existingRideSchedules = existingRideSchedulesOptional.get();
//	            existingEmployee.setName(employee.getName());
//	            existingEmployee.setSalary(employee.getSalary());
	            // Update other fields as needed
			 existingRideSchedules.setMotorisUserId(rideschedules.getMotorisUserId());
			 existingRideSchedules.setRideFrom(rideschedules.getRideFrom());

	            return rideschedulesRepository.save(existingRideSchedules);
	        } else {
	            // Handle the case where the employee with the given id is not found
	            return null; // You can throw an exception or return a meaningful response
	        }
	}

	@Override
	public void deleteByRideSchedulesId(int id) {
		rideschedulesRepository.deleteById(id);
		
		
	}

	@Override
	public List<RideSchedules> fetchAll() {
		// TODO Auto-generated method stub
		return rideschedulesRepository.fetchAllFromRideSchedules();
	}

	@Override
	public RideSchedules getRideSchedulesId(int id) {
		
		return rideschedulesRepository.fetchUsingRideSchedule(id);
	}

	@Override
	public Long findRideIdByRideFromAndRideTo(String rideFrom, String rideTo) {
		// TODO Auto-generated method stub
		return rideschedulesRepository.findByRideFromAndRideTo(rideFrom, rideTo);
	}

	@Override
	public Long findByAmount(String rideFrom, String rideTo) {
		// TODO Auto-generated method stub
		return rideschedulesRepository.findByRideFareAmount(rideFrom, rideTo);
	}

	

//	@Override
//	public List<RideSchedules> findAvailableRides(String fromLocation, String toLocation,double rideAmount) {
//		// TODO Auto-generated method stub
//		return rideschedulesRepository.findAvailableRides(fromLocation, toLocation,rideAmount);
//	}

//	@Override
//	public List<RideSchedules> findRidesByDistance(Integer fromDistance, Integer toDistance) {
//		// TODO Auto-generated method stub
//		return rideschedulesRepository.findRidesByDistanceRange(fromDistance, toDistance);
//	}

//	@Override
//	public List<Object[]> findAvailableRidesForDistance(int distances) {
//		// TODO Auto-generated method stub
//		return rideschedulesRepository.findAvailableRidesForDistance(distances);
//	}

	



//	@Override
//	public List<RideSchedules> findRidesByDistance(int distances) {
//		List<Distances> distance=distancesRepository.findDistancesInRange(distances, null)
//		return null;
//	}

}
