package com.RideSharingManagementModule.RideSharingModule.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Booking {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO) 
	private int bookingId;
	private int bookedOn;
	private int noOfSeats;
	private int totalAmount;
	private String paymentMode;
	private int riderUserId;
	
	public int getRiderUserId() {
		return riderUserId;
	}

	public void setRiderUserId(int riderUserId) {
		this.riderUserId = riderUserId;
	}

	@ManyToOne //it's refers the relationship
	@JoinColumn(name="rideSchedulesId",referencedColumnName="id")//foregin key and primary key
	public RideSchedules rideSchedules;//primary key table name


	public Booking() {
		
	}

	public Booking(int bookingId, int bookedOn, int noOfSeats, int totalAmount, String paymentMode, int riderUserId,
			RideSchedules rideSchedules) {
		super();
		this.bookingId = bookingId;
		this.bookedOn = bookedOn;
		this.noOfSeats = noOfSeats;
		this.totalAmount = totalAmount;
		this.paymentMode = paymentMode;
		this.riderUserId = riderUserId;
		this.rideSchedules = rideSchedules;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getBookedOn() {
		return bookedOn;
	}

	public void setBookedOn(int bookedOn) {
		this.bookedOn = bookedOn;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public RideSchedules getRideSchedules() {
		return rideSchedules;
	}

	public void setRideSchedules(RideSchedules rideSchedules) {
		this.rideSchedules = rideSchedules;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", bookedOn=" + bookedOn + ", noOfSeats=" + noOfSeats
				+ ", totalAmount=" + totalAmount + ", paymentMode=" + paymentMode + ", riderUserId=" + riderUserId
				+ ", rideSchedules=" + rideSchedules + "]";
	}
	
	

	
}
