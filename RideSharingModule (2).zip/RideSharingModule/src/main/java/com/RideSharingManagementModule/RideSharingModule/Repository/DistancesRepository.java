package com.RideSharingManagementModule.RideSharingModule.Repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.RideSharingManagementModule.RideSharingModule.Model.Distances;
import com.RideSharingManagementModule.RideSharingModule.Model.RideSchedules;

@Repository
public interface DistancesRepository extends JpaRepository<Distances,Integer>{

	@Query(value="select d from Distances d") //alias name need to use here we can't use astrick(*) here
	
	public List<Distances> fetchAllFromDistances();
	
	
	@Query(value="select d from Distances d where ridefrom=:val ")
	public Distances fetchUsingRideFrom(@Param("val") String ridefrom);//@Param used as a parameter in that specifiy variable=val and next is passing value is int
	
	@Query(value="select s from Distances s")
	public List<Distances> fetchAllDistances();
	
	@Query(value="select s from Distances s where id=:val")
	public Distances fetchAllRideFare(@Param("val") int id);
	
	@Query("SELECT e.totalfare FROM Distances e")
    public List<Distances> findByFareAmount();
	

	
	@Query("SELECT rs FROM Distances rs WHERE rs.ridefrom=:fromLocation AND rs.rideto=:toLocation AND rs.totalfare=:fareAmount")
	List<Distances> findAvailableRides(@Param("fromLocation")String fromLocation,@Param("toLocation") String toLocation,@Param("fareAmount")double fareAmount);
	
	
	@Query("SELECT d FROM Distances d WHERE d.ridefrom=:fromLocation AND d.rideto=:toLocation AND d.totalfare BETWEEN :minFare AND :maxFare")
	List<Distances> findAvailableRidesByFareRange(@Param("fromLocation") String fromLocation, @Param("toLocation") String toLocation, @Param("minFare") Double minFare, @Param("maxFare") Double maxFare);
	
//	@Query("select RideSchedules.rideFrom,RideSchedules.rideTo,RideSchedules.rideFare from RideSchedules  inner join Distances on  RideSchedules.rideFrom=Distances.ridefrom and RideSchedules.rideTo=Distances.rideto and RideSchedules.rideFare=Distances.totalfare")
//	public List<Distances> findDistanceDetails(String ridefrom,String rideto,double totalfare);

	//select RideSchedules.rideFrom,RideSchedules.rideTo,RideSchedules.rideFare from RideSchedules inner join Distances ON RideSchedules.rideFrom=Distances.ridefrom and RideSchedules.rideTo=Distances.rideto and RideSchedules.rideFare=Distances.totalfare
//	@Query("SELECT d FROM Distances d WHERE d.distancekms BETWEEN:minDistance AND :maxDistance")
//	List<Distances>findDistancesInRange(int minDistance,Integer maxDistance);
}
