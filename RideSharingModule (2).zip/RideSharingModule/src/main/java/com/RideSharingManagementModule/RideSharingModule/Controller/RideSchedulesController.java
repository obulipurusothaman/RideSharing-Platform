package com.RideSharingManagementModule.RideSharingModule.Controller;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.RideSharingManagementModule.RideSharingModule.Model.RideSchedules;
import com.RideSharingManagementModule.RideSharingModule.Service.RideSchedulesService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api")
public class RideSchedulesController {
	
	@Autowired
	private RideSchedulesService rideschedulesService;

	@PostMapping("/rides/schedule")
	public ResponseEntity<RideSchedules>  saveRideSchedules(@RequestBody RideSchedules rideschedules) {
		RideSchedules createdRideSchedules = rideschedulesService.createRideSchedules(rideschedules);
		return new ResponseEntity<>(createdRideSchedules, HttpStatus.CREATED);
	}
	
	@GetMapping("/getAllRideSchedules")
	public ResponseEntity<List<RideSchedules>> getAllRideSchedules(){
		List<RideSchedules> rideSchedulesList=rideschedulesService.getAllRideSchedules();
		if (!rideSchedulesList.isEmpty()) {
            return new ResponseEntity<>(rideSchedulesList, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
        }
		
	}
	
	@GetMapping("/rides/search/{id}")
	public ResponseEntity<RideSchedules> getRideSchedulesById(@PathVariable int id){
		Optional<RideSchedules> rideSchedules=rideschedulesService.getRideSchedules(id);
		 return rideSchedules.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
	                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));

	}
	
	@PutMapping("/updateRideSchedules/{id}")
	public ResponseEntity<RideSchedules> updateRideSchedules(@PathVariable int id,@RequestBody RideSchedules rideschedules ){
		RideSchedules updatedRideSchedules =rideschedulesService.updateRideSchedules(id, rideschedules);
		 if (updatedRideSchedules != null) {
	            return new ResponseEntity<>(updatedRideSchedules, HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
		
	}
	
	@DeleteMapping("/deleteRideSchedules/{id}")
	public ResponseEntity<Void> deleteByRideSchedulesId(@PathVariable int id) {
		rideschedulesService.deleteByRideSchedulesId(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
	
	
	//custom query
	@GetMapping("/rideSchedulesFetch")
	public List<RideSchedules> fetchController(){
		return rideschedulesService.fetchAll();
	}
	
	@GetMapping("/fetchingRideSchedulesId/{id}")
	public RideSchedules fetchRideSchedulesById(@PathVariable int id) {
		return rideschedulesService.getRideSchedulesId(id);
	}
	
	
	@PostMapping("/{rideFrom}/{rideTo}/id")
	public ResponseEntity<Long> getRideIdByRideFromAndRideTo(
		@PathVariable String rideFrom,
		@PathVariable String rideTo){
		Long rideId=rideschedulesService.findRideIdByRideFromAndRideTo(rideFrom, rideTo);
		
		if(rideId!=null) {
			return ResponseEntity.ok(rideId);
		}
		else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@GetMapping("/{rideFrom}/{rideTo}/rideFare")
	public ResponseEntity<Long> getRideByFareValue(
			@PathVariable String rideFrom,
			@PathVariable String rideTo){
			Long rideFare=rideschedulesService.findByAmount(rideFrom, rideTo);
			if(rideFare!=null) {
				return ResponseEntity.ok(rideFare);
				}
			else {
				return ResponseEntity.notFound().build();
			}
			}
			
	}
	
	
//	@GetMapping("/find")
//	public List<RideSchedules> findAvailableRides(@RequestParam String fromLocation,@RequestParam String toLocation,@RequestParam double rideAmount){
//		return rideschedulesService.findAvailableRides(fromLocation, toLocation,rideAmount);
//	}
//	
//	@GetMapping("/available/{distances}")
//	public List<Object[]> getAvailableRidesForDistance(@PathVariable int distances){
//		return rideschedulesService.findAvailableRidesForDistance(distances);
//	}


