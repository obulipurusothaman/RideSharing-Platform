package com.RideSharingManagementModule.RideSharingModule.Service;

import java.util.List;
import java.util.Optional;

import com.RideSharingManagementModule.RideSharingModule.Model.Booking;




public interface BookingService {
	Booking createBooking(Booking booking);
	List<Booking> getAllBooking();
	Optional<Booking> getBooking(int bookingId);
	Optional<Booking>getNoOfSeats(int noOfSeats);
	Booking updateBooking(int bookingId,Booking booking);
	void deleteByBookingId(int bookingId);
	 List<Booking> fetchAll();
	Booking fetchUsingBookingMode(String paymentMode);
	
	Booking bookRide(Booking booking);
//	Booking confirmBooking(Booking booking);
	//Exception
	Booking getNoOfSeatsAvailable(Booking booking);
   

	
	
	
	
}
