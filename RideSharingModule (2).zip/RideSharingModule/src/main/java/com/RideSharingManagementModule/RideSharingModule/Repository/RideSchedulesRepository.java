package com.RideSharingManagementModule.RideSharingModule.Repository;

import java.sql.Driver;
import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.RideSharingManagementModule.RideSharingModule.Model.RideSchedules;

@Repository
public interface RideSchedulesRepository extends JpaRepository<RideSchedules,Integer> {

	@Query(value="select r from RideSchedules r") //alias name need to use here we can't use astrick(*) here
	
	public List<RideSchedules> fetchAllFromRideSchedules();
	

	@Query(value="select d from RideSchedules d where id=:val")
	public RideSchedules fetchUsingRideSchedule(@Param("val") int id);//@Param used as a parameter in that specifiy variable=val and next is passing value is int
     
	@Query(value="select r.id from RideSchedules r where r.rideFrom=:rideFrom AND r.rideTo=:rideTo")
	Long findByRideFromAndRideTo(@Param("rideFrom")String rideFrom,@Param("rideTo")String rideTo);
	
	
	@Query(value="SELECT r.rideFare from RideSchedules r where r.rideFrom=:rideFrom AND r.rideTo=:rideTo")
	Long findByRideFareAmount(@Param("rideFrom")String rideFrom,@Param("rideTo")String rideTo);
	
	
	
//	RideSchedules findByBookingId(int id)
//    @Query("SELECT rs.rideFrom,rs.rideTo,rs.rideFare FROM RideSchedules rs WHERE:distances=(SELECT d.distancekms FROM Distances d WHERE d.ridefrom=rs.rideFrom AND d.rideto=rs.rideTo AND d.totalfare=rs.rideFare)")
//    List<Object[]>findAvailableRidesForDistance(int distances);
	
//	 @Query("SELECT r FROM RideSchedules r " +
//	           "INNER JOIN Distances d ON r.rideFrom = d.ridefrom AND r.rideTo = d.rideto " +
//	           "WHERE d.distancekms BETWEEN :minDistance AND :maxDistance")
//	    List<RideSchedules> findAvailableRidesByDistance(Integer minDistance, Integer maxDistance);
	
//	@Query("SELECT rs FROM RideSchedules rs JOIN Distances d ON rs.rideFrom=d.ridefrom AND rs.rideTo=d.rideto WHERE d.distancekms>=:fromDistance AND d.distancekms<=:toDistance")
//	List<RideSchedules> findRidesByDistanceRange(@Param("fromDistance")Integer fromDistance,@Param("toDistance")Integer toDistance );
	
//	@Query("SELECT rs FROM RideSchedules rs WHERE rs.rideFrom=:fromLocation AND rs.rideTo=:toLocation AND rs.rideFare=:rideAmount")
//	List<RideSchedules> findAvailableRides(@Param("fromLocation")String fromLocation,@Param("toLocation") String toLocation,@Param("rideAmount") double rideAmount);
}
