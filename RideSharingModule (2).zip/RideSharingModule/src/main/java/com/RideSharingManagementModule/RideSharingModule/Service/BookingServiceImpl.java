package com.RideSharingManagementModule.RideSharingModule.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.RideSharingManagementModule.RideSharingModule.Model.Booking;
import com.RideSharingManagementModule.RideSharingModule.Repository.BookingRepository;
import com.RideSharingManagementModule.RideSharingModule.Repository.RideSchedulesRepository;
import com.RideSharingModule.ExceptionHandling.NoOfSeatsExistsException;

import jakarta.transaction.Transactional;



@Service
public class BookingServiceImpl implements BookingService {

	@Autowired 
	private BookingRepository bookingRepository;
	
	@Autowired
	private RideSchedulesRepository rideschedulesRepository;
	

	@Override
	public Booking createBooking(Booking booking) {
		
		 return bookingRepository.save(booking);
		
	}

	@Override
	public List<Booking> getAllBooking() {
		List<Booking> booking=bookingRepository.findAll();
	
		return booking;
	}

	@Override
	public Optional<Booking> getBooking(int bookingId) {
		
		return bookingRepository.findById(bookingId);
	}

	@Override
	public Optional<Booking>getNoOfSeats(int noOfSeats) {
		// TODO Auto-generated method stub
		//Optional<Booking> isNoOfSeatsExists=bookingRepository.findByNoOfSeats(booking.getNoOfSeats());
//		if(isNoOfSeatsExists.isPresent()) {
//			throw new NoOfSeatsExistsException("No Of Seats should be less than or equal to two:"+booking.getNoOfSeats());
//		}
		return bookingRepository.findByNoOfSeats(noOfSeats);
		
	}
	@Override
	public Booking updateBooking(int bookingId, Booking booking) {
		 Optional<Booking> existingBookingOptional =bookingRepository.findById(bookingId);
		 if (existingBookingOptional.isPresent()) {
			 Booking existingBookingSchedules =  existingBookingOptional.get();
			 
			
			 existingBookingSchedules.setPaymentMode(booking.getPaymentMode());
			 existingBookingSchedules.setNoOfSeats(booking.getNoOfSeats());
			 existingBookingSchedules.setTotalAmount(booking.getTotalAmount());
			 existingBookingSchedules.setBookingId(booking.getBookingId());

	            return bookingRepository.save(existingBookingSchedules);
	        } else {
	            // Handle the case where the employee with the given id is not found
	            return null; // You can throw an exception or return a meaningful response
	        }
	}

	@Override
	public void deleteByBookingId(int bookingId) {
		bookingRepository.deleteById(bookingId);
		
	}
	
	//custom query
	@Override
	public List<Booking> fetchAll(){
		return bookingRepository.fetchAllFromBooking();
	}
	
	
	public Booking fetchUsingBookingMode(String paymentMode) {
		// TODO Auto-generated method stub
		return bookingRepository.fetchUsingBookingMode(paymentMode);
	}

	@Override
	public Booking getNoOfSeatsAvailable(Booking booking) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booking bookRide(Booking booking) {
		// TODO Auto-generated method stub
		return bookingRepository.save(booking);
	}
	
//	public RideSchedules findRideSchedulesByBookingId(int bookingId) {
//		return rideschedulesRepository.findByBookingId(bookingId);
//	}

//	@Override
//	public Booking confirmBooking(Booking booking) {
//		// TODO Auto-generated method stub
//		return bookingRepository.save(booking);
//	}

	
	
	

	
		
	}



