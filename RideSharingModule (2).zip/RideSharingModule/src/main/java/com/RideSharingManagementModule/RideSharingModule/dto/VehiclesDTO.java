package com.RideSharingManagementModule.RideSharingModule.dto;


import java.util.Date;




public class VehiclesDTO {
	private String registrationNo;
	
	private int belongsToUserId;
	
	private int vehicleTypeId;
	
	private String inspectionStatus;
	
	private int inspectedByUserId;
	
	private Date inspectedOn;
//	@ManyToOne
//	@JoinColumn(name = "TypeId")
//	private VehicleTypes ID;

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public int getBelongsToUserId() {
		return belongsToUserId;
	}

	public void setBelongsToUserId(int belongsToUserId) {
		this.belongsToUserId = belongsToUserId;
	}

	public int getVehicleTypeId() {
		return vehicleTypeId;
	}

	public void setVehicleTypeId(int vehicleTypeId) {
		this.vehicleTypeId = vehicleTypeId;
	}

	public String getInspectionStatus() {
		return inspectionStatus;
	}

	public void setInspectionStatus(String inspectionStatus) {
		this.inspectionStatus = inspectionStatus;
	}

	public int getInspectedByUserId() {
		return inspectedByUserId;
	}

	public void setInspectedByUserId(int inspectedByUserId) {
		this.inspectedByUserId = inspectedByUserId;
	}

	public Date getInspectedOn() {
		return inspectedOn;
	}

	public void setInspectedOn(Date inspectedOn) {
		this.inspectedOn = inspectedOn;
	}

	

	

	
	

//	public VehicleTypes getID() {
//		return ID;
//	}
//
//	public void setID(VehicleTypes iD) {
//		ID = iD;
//	}
//
	}
