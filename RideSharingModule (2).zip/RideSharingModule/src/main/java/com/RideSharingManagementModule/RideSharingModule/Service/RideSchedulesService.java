package com.RideSharingManagementModule.RideSharingModule.Service;

import java.util.List;
import java.util.Optional;


import com.RideSharingManagementModule.RideSharingModule.Model.RideSchedules;

public interface RideSchedulesService {	
	RideSchedules createRideSchedules(RideSchedules rideschedules);
	List<RideSchedules> getAllRideSchedules();
	Optional<RideSchedules> getRideSchedules(int id);
	RideSchedules updateRideSchedules(int id,RideSchedules rideschedules);
	void deleteByRideSchedulesId(int id);
	List<RideSchedules> fetchAll();
	RideSchedules getRideSchedulesId(int id);
	Long findByAmount(String rideFrom,String rideTo);
	Long findRideIdByRideFromAndRideTo(String rideFrom,String rideTo);
	
//	List<RideSchedules> findAvailableRides(String fromLocation,String toLocation,double rideAmount);
//	List<RideSchedules> findRidesByDistance(int distances);
//	List<Object[]>findAvailableRidesForDistance(int distances);
	
//	List<RideSchedules> findRidesByDistance(Integer fromDistance,Integer toDistance);

}
