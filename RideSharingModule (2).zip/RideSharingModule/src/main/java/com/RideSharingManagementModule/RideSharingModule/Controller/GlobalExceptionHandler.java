package com.RideSharingManagementModule.RideSharingModule.Controller;

import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.RideSharingModule.ExceptionHandling.BookingCreationFailed;
import com.RideSharingModule.ExceptionHandling.ErrorDetails;
import com.RideSharingModule.ExceptionHandling.NoOfSeatsExistsException;

@RestControllerAdvice
@ControllerAdvice
public class GlobalExceptionHandler {

	//Custom Exception
	@ExceptionHandler(NoOfSeatsExistsException.class)
	public ResponseEntity<ErrorDetails> handleMaximunLimitReachedException() {
		ErrorDetails error=new ErrorDetails(400,"Can't Book A Ride",new Date());
		return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(BookingCreationFailed.class)
	public ResponseEntity<ErrorDetails> approvalNotAccepted() {
		ErrorDetails error=new ErrorDetails(400,"Can't Book A Ride",new Date());
		return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
	}
	
}
