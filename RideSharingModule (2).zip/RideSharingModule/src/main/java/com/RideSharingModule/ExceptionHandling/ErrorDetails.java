package com.RideSharingModule.ExceptionHandling;

import java.time.LocalDateTime;
import java.util.Date;




public class ErrorDetails {

	
	private Integer errorCode;
	private String errordesc;
	private Date date;
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Integer getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrordesc() {
		return errordesc;
	}
	public void setErrordesc(String errordesc) {
		this.errordesc = errordesc;
	}
	public ErrorDetails(Integer errorCode, String errordesc, Date date) {
		super();
		this.errorCode = errorCode;
		this.errordesc = errordesc;
		this.date = date;
	}
	
	
	
	
	
}
