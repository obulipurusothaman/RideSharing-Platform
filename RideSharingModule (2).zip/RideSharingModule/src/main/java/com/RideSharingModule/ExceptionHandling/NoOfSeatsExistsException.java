package com.RideSharingModule.ExceptionHandling;


public class NoOfSeatsExistsException extends RuntimeException{

	public NoOfSeatsExistsException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
