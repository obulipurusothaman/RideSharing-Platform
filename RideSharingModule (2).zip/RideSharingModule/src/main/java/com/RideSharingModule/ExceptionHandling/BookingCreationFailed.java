package com.RideSharingModule.ExceptionHandling;

public class BookingCreationFailed extends RuntimeException {

	public BookingCreationFailed(String msg) {
		super(msg);
		System.out.println(msg);
		
		
	}

	
}
